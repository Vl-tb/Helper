#include "types.h"
#include "stat.h"
#include "user.h"

char buf[512];

void
cat(int fd1, int fd2)
{
  int n;

  while((n = read(fd1, buf, sizeof(buf))) > 0) {
    if (write(1, buf, n) != n) {
      printf(1, "cat: write error\n");
      exit();
    }
    else{
    write(fd2,buf,sizeof(buf));
    }
  }
  if(n < 0){
    printf(1, "cat: read error\n");
    exit();
  }
}

int
main(int argc, char *argv[])
{
  int fd1,fd2, i;

  if(argc <= 1){
    cat(0,0);
    exit();
  }


  if((fd1 = open(argv[0], 0)) < 0){
    printf(1, "cat: cannot open %s\n", argv[i]);
    exit();
    }
    
  if((fd2 = open(argv[1], 0)) < 0){
    printf(1, "cat: cannot open %s\n", argv[i]);
    exit();
    }
    cat(fd1,fd2);
    close(fd1);
    close(fd2);
  }
  exit();
}
